# Tipos de variables [Python]
# Ejercicios de práctica

# Autor: Inove Coding School
# Version: 3.0

# IMPORTANTE: NO borrar los comentarios
# que aparecen en verde con el hashtag "#"

# Ejercicios de práctica numérica

numero_1 = 5
numero_2 = 7

# Realizar la suma de las dos variables
# Crear una variable llamada suma donde se 
# almacene el valor de la suma de las variable numero_1 y numero_2
# ej:
# suma = .....

suma = numero_1+numero_2


# Imprimir en pantalla el resultado de la suma
# print(....)

print(suma)

# Repita el procedimiento para realizar la resta
# Crear una variable llamada resta donde se 
# almacene el valor de la resta de numero_1 menos numero_2
numero_1 = 5
numero_2 = 7
resta = numero_1-numero_2

# Imprimir en pantalla el resultado de la resta
print(resta)